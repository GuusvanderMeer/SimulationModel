#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 23 12:49:52 2024

@author: fl
"""

import calliope
import pandas as pd

calliope.set_log_verbosity("INFO", include_solver_output=True)
#%%

model = calliope.Model('model.yaml')

#%%

model.build()
model.solve()